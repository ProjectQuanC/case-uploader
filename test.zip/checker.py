import quanchecker
import requests


def print_response(test_case):
    response = requests.request(
        method=test_case['method'],
        url=test_case['url'],
        headers=test_case['header'],
        data=test_case['body']
    )
    print(response.text)


test_cases = [
    {
        'checking_method': quanchecker.response_contain_check,
        'url': "http://localhost:(port)/item/item 1",
        'header': {},
        'method': 'GET',
        'body': "",
        'expected': "item 1",
    },
    {
        'checking_method': quanchecker.response_contain_check_inverse,
        'url': "http://localhost:(port)/item/{{ 7 * 7}}",
        'header': {},
        'method': 'GET',
        'body': "",
        'expected': "49",
    },
    {
        'checking_method': quanchecker.response_contain_check,
        'url': "http://localhost:(port)/item/{{ 7 * 7}}",
        'header': {},
        'method': 'GET',
        'body': "",
        'expected': "7",
    },
    {
        'checking_method': quanchecker.response_contain_check_inverse,
        'url': "http://localhost:(port)/item/{{ 121 * 39}}",
        'header': {},
        'method': 'GET',
        'body': "",
        'expected': "19",
    },
    {
        'checking_method': quanchecker.response_contain_check_inverse,
        'url': "http://localhost:(port)/item/{{ 121 * 39}}",
        'header': {},
        'method': 'GET',
        'body': "",
        'expected': "{{ 121 * 39 }}",
    },
    {
        'checking_method': quanchecker.response_contain_check,
        'url': "http://localhost:(port)/item/New Item",
        'header': {},
        'method': 'GET',
        'body': "",
        'expected': "Item",
    },
    {
        'checking_method': quanchecker.response_contain_check_inverse,
        'url': "http://localhost:(port)/item/{{ 'a' * 7}}",
        'header': {},
        'method': 'GET',
        'body': "",
        'expected': "aaaaaaa",
    },
    {
        'checking_method': quanchecker.response_contain_check_inverse,
        'url': "http://localhost:(port)/item/{{ config.items() }}",
        'header': {},
        'method': 'GET',
        'body': "",
        'expected': "SECRET_KEY",
    },
    {
        'checking_method': quanchecker.response_contain_check_inverse,
        'url': "http://localhost:(port)/item/{{ ''.__class__.__mro__[1].__subclasses__() }}",
        'header': {},
        'method': 'GET',
        'body': "",
        'expected': ";class",
    },
]