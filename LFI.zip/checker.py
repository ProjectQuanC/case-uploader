import json
import quanchecker

urls = ["http://localhost:(port)/image"]

headers = [{
  'Content-Type': 'application/json'
}]

test_cases = [
    {
        'checking_method': quanchecker.response_hash_check,
        'url': urls[0],
        'header': headers[0],
        'method': 'POST',
        'body': json.dumps({
            "image_name": "side0ym19aj.png"
        }),
        'expected': "4E9587AD983044CE3DA1A6B747AF051376592B573105A1CD7C160C7731DE143B",
    },
    {
        'checking_method': quanchecker.response_hash_check,
        'url': urls[0],
        'header': headers[0],
        'method': 'POST',
        'body': json.dumps({
            "image_name": "lo8s72txt012.jpg"
        }),
        'expected': "5AF9DD41E504E502B790387E8FBB6AFD1C34681FE5DDC7539D075A852A4E4BF0",
    },
    {
        'checking_method': quanchecker.response_hash_check,
        'url': urls[0],
        'header': headers[0],
        'method': 'POST',
        'body': json.dumps({
            "image_name": "kl9df.2al0ah.jpg"
        }),
        'expected': "F50CA262558BBC66818F672722AADC6177ED7CCA88902D3CCBAF0205AAF32762",
    },
    {
        'checking_method': quanchecker.response_hash_check,
        'url': urls[0],
        'header': headers[0],
        'method': 'POST',
        'body': json.dumps({
            "image_name": "2la0fk-s.csv.jpg"
        }),
        'expected': "F5FD7D9168CFF19E115A78F85811439BBC5E74DACFEE6E65291800F0481209A8",
    },
    {
        'checking_method': quanchecker.response_based_check,
        'url': urls[0],
        'header': headers[0],
        'method': 'POST',
        'body': json.dumps({
            "image_name": "secret.txt"
        }),
        'expected': { "detail": "Unsupported file type" },
    },
    {
        'checking_method': quanchecker.response_based_check,
        'url': urls[0],
        'header': headers[0],
        'method': 'POST',
        'body': json.dumps({
            "image_name": "secret_none.png"
        }),
        'expected': { "detail": "Image not found" },
    },
    {
        'checking_method': quanchecker.response_based_check,
        'url': urls[0],
        'header': headers[0],
        'method': 'POST',
        'body': json.dumps({
            "image_name": "..\\secret 2.csv"
        }),
        'expected': { "detail": "Invalid image name" },
    },
    {
        'checking_method': quanchecker.response_based_check,
        'url': urls[0],
        'header': headers[0],
        'method': 'POST',
        'body': json.dumps({
            "image_name": "restricted\\kuia9s01nsla.jpg"
        }),
        'expected': { "detail": "Invalid image name" },
    },
    {
        'checking_method': quanchecker.response_based_check,
        'url': urls[0],
        'header': headers[0],
        'method': 'POST',
        'body': json.dumps({
            "image_name": "../ic8i9olus9a0.jpg"
        }),
        'expected': { "detail": "Invalid image name" },
    },
    {
        'checking_method': quanchecker.response_based_check,
        'url': urls[0],
        'header': headers[0],
        'method': 'POST',
        'body': json.dumps({
            "image_name": "another secret.png.txt"
        }),
        'expected': { "detail": "Unsupported file type" },
    },
]