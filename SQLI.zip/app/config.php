<?php
// Database configuration
$host = 'qx-mysqldb-01.mysql.database.azure.com';
$db = 'yourdb';
$user = 'quanxa1';
$pass = 'Security@2023##';
$charset = 'utf8mb4';